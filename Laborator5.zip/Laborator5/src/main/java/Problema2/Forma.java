package Problema2;

public interface Forma {
    public double arie();
    public double perimetru();



}
