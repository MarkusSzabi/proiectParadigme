package Problema4;

public class Problema4 {
    public static void main(String[] args) {
        Rectangle dreptughi = new Rectangle(3 ,  2);
        System.out.println("Dreptunghi => Arie: " + dreptughi.arie() + " Perimetru: " + dreptughi.perimetru());
    }
}
