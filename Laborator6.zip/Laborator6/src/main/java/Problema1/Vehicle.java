package Problema1;

public abstract class Vehicle {
    public abstract String speedUp();
}
